package com.cg.carservice.bean;

public class Car {
private String carName,registrationNumber,engineNumber,chasisNumber;
private int totalFreeServices;
private int noOfServicesDone;
private int noOfServicesPending;
private long kmsForNextService;
private long currentKms;
private Owner owner;
public Car() {}

public Car(String carName, long currentKms,String registrationNumber,String engineNumber,String chasisNumber,
		int totalFreeServices,int noOfServicesDone,int noOfServicesPending, Owner owner) {
	super();
	this.carName = carName;
	this.registrationNumber = registrationNumber;
	this.engineNumber=engineNumber;
	this.chasisNumber=chasisNumber;
	this.totalFreeServices = totalFreeServices;
	this.noOfServicesDone = noOfServicesDone;
	this.noOfServicesPending = noOfServicesPending;
	this.kmsForNextService = kmsForNextService;
    this.owner = owner;
    this.currentKms = currentKms;
}

public Car(String carName, String registrationNumber, String engineNumber, String chasisNumber, int totalFreeServices,
		int noOfServicesDone, int noOfServicesPending, long kmsForNextService, long currentKms, Owner owner) {
	super();
	this.carName = carName;
	this.registrationNumber = registrationNumber;
	this.engineNumber = engineNumber;
	this.chasisNumber = chasisNumber;
	this.totalFreeServices = totalFreeServices;
	this.noOfServicesDone = noOfServicesDone;
	this.noOfServicesPending = noOfServicesPending;
	this.kmsForNextService = kmsForNextService;
	this.currentKms = currentKms;
	this.owner = owner;
}

public String getCarName() {
	return carName;
}

public void setCarName(String carName) {
	this.carName = carName;
}

public String getRegistrationNumber() {
	return registrationNumber;
}

public void setRegistrationNumber(String registrationNumber) {
	this.registrationNumber = registrationNumber;
}

public int getTotalFreeServices() {
	return totalFreeServices;
}

public void setTotalFreeServices(int totalFreeServices) {
	this.totalFreeServices = totalFreeServices;
}

public int getNoOfServicesDone() {
	return noOfServicesDone;
}

public void setNoOfServicesDone(int noOfServicesDone) {
	this.noOfServicesDone = noOfServicesDone;
}

public int getNoOfServicesPending() {
	return noOfServicesPending;
}

public void setNoOfServicesPending(int noOfServicesPending) {
	this.noOfServicesPending = noOfServicesPending;
}

public long getKmsForNextService() {
	return kmsForNextService;
}

public String getEngineNumber() {
	return engineNumber;
}

public void setEngineNumber(String engineNumber) {
	this.engineNumber = engineNumber;
}

public String getChasisNumber() {
	return chasisNumber;
}

public void setChasisNumber(String chasisNumber) {
	this.chasisNumber = chasisNumber;
}

public void setKmsForNextService(long kmsForNextService) {
	this.kmsForNextService = kmsForNextService;
}


@Override
public String toString() {
	return " carName=" + carName +"\n "+"registrationNumber=" + registrationNumber + "\n "+" engineNumber=" + engineNumber
			+"\n "+ " chasisNumber=" + chasisNumber +"\n "+ ", totalFreeServices=" + totalFreeServices + "\n "+" noOfServicesDone="
			+ noOfServicesDone +"\n "+ " noOfServicesPending=" + noOfServicesPending +"\n "+ " kmsForNextService="
			+ kmsForNextService + "\n "+" currentKms=" + currentKms +"\n "+ " owner=" + owner ;
}

public long getCurrentKms() {
	return currentKms;
}

public void setCurrentKms(long currentKms) {
	this.currentKms = currentKms;
}

public Owner getOwner() {
	return owner;
}

public void setOwner(Owner owner) {
	this.owner = owner;
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((carName == null) ? 0 : carName.hashCode());
	result = prime * result + ((chasisNumber == null) ? 0 : chasisNumber.hashCode());
	result = prime * result + (int) (currentKms ^ (currentKms >>> 32));
	result = prime * result + ((engineNumber == null) ? 0 : engineNumber.hashCode());
	result = prime * result + (int) (kmsForNextService ^ (kmsForNextService >>> 32));
	result = prime * result + noOfServicesDone;
	result = prime * result + noOfServicesPending;
	result = prime * result + ((owner == null) ? 0 : owner.hashCode());
	result = prime * result + ((registrationNumber == null) ? 0 : registrationNumber.hashCode());
	result = prime * result + totalFreeServices;
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Car other = (Car) obj;
	if (carName == null) {
		if (other.carName != null)
			return false;
	} else if (!carName.equals(other.carName))
		return false;
	if (chasisNumber == null) {
		if (other.chasisNumber != null)
			return false;
	} else if (!chasisNumber.equals(other.chasisNumber))
		return false;
	if (currentKms != other.currentKms)
		return false;
	if (engineNumber == null) {
		if (other.engineNumber != null)
			return false;
	} else if (!engineNumber.equals(other.engineNumber))
		return false;
	if (kmsForNextService != other.kmsForNextService)
		return false;
	if (noOfServicesDone != other.noOfServicesDone)
		return false;
	if (noOfServicesPending != other.noOfServicesPending)
		return false;
	if (owner == null) {
		if (other.owner != null)
			return false;
	} else if (!owner.equals(other.owner))
		return false;
	if (registrationNumber == null) {
		if (other.registrationNumber != null)
			return false;
	} else if (!registrationNumber.equals(other.registrationNumber))
		return false;
	if (totalFreeServices != other.totalFreeServices)
		return false;
	return true;
}

}
