package com.cg.carservice.client;

import java.util.Scanner;

import com.cg.carservice.exceptions.RegistrationNumberNotFound;
import com.cg.carservice.service.Service;
import com.cg.carservice.service.ServiceImpl;

public class MainClass {
	static Scanner sc = new Scanner(System.in);
	static Service services = new ServiceImpl();
public static void main(String args[])  {
	main();
	int userChoice = sc.nextInt();
	carServiceManagementSystemMainMenu(userChoice);
}

private static void carServiceManagementSystemMainMenu(int userChoice) {
	switch (userChoice) {
	case 1:
		System.out.println("Enter Car Registration number:-");
		String registrationNumber = sc.next();
		System.out.println("Enter Current Running Kms");
		long currentKms = sc.nextLong();
		System.out.println("Enter Car Name:-");
		String carName = sc.next();
		System.out.println("Enter Total services:-");
		int totalServices = sc.nextInt();
		System.out.println("Enter  Owner Name:-");
		String ownerName = sc.next();
		System.out.println("Enter Phone number of Customer:-");
		long mobileNumber = sc.nextLong();
		System.out.println("Enter Engine Number:-");
		String engineNumber = sc.next();
		System.out.println("Enter Chasis Number:-");
		String chasisNumber = sc.next();
		services.registerCustomer(registrationNumber, currentKms, carName,
				engineNumber, chasisNumber, totalServices, ownerName, mobileNumber);
		break;
	
	case 2:
		try {
			System.out.println("Enter Car registration number:-");
			String registrationNumber1 = sc.next();
			System.out.println(services.carService(registrationNumber1));
			break;}
		catch (RegistrationNumberNotFound e) {
			e.printStackTrace();
			break;
			
		}
	
	case 3:
		System.out.println(services.getAll());
		break;
		
	case 4:
		System.exit(0);
   
	default:System.out.println("Invalid choice. Please try again!!!!!");
		break;
	}
	main(null);
}

private static void main() {
	System.out.println("_-_-_-_-_-_-_*************Welocme to Lucky Da Garage*************_-_-_-_-_-_-_");
	System.out.println("Please choose any one option:-");
	System.out.println("1. Create Account...");
	System.out.println("2. Book Service");	
	System.out.println("3. Get all Cars Details...");
	System.out.println("4. Exit");
}
}