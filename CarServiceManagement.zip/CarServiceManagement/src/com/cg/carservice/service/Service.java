package com.cg.carservice.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.carservice.bean.Car;
import com.cg.carservice.exceptions.RegistrationNumberNotFound;

public interface Service {
	public Car registerCustomer(String registrationNumber,long currentKms,String carName,String engineNumber,String chasisNumber,int totalServices,String ownerName,long mobileNumber);
	public Car carService(String registrationNumber) throws RegistrationNumberNotFound;
	public Car findOne(String registrationNumber) throws RegistrationNumberNotFound;
	public ArrayList<Car> getAll();
}
