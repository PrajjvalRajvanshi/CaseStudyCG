package com.cg.carservice.test;
import static org.junit.Assert.assertEquals;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.carservice.DbUtil.CarServiceDbUtil;
import com.cg.carservice.bean.Car;
import com.cg.carservice.bean.Owner;
import com.cg.carservice.exceptions.RegistrationNumberNotFound;
import com.cg.carservice.service.Service;
import com.cg.carservice.service.ServiceImpl;
public class ServiceImplTest {
	private static Service service;
	
	@BeforeClass
	public static void setUpTestEnv() {
		service = new ServiceImpl();
	} 
	
	@Before
	public void setUpTestData() {
		
		Car car1= new Car("Swift","UP12AD7844","1234556","34234234",10,2, 8,5000,10000,new Owner("Prajjval",828485087));
		Car car2= new Car("Bolero","UP12AD9999","1233456","45454234",8,2,6,5000,10000,new Owner("June",768678778));
		Car car3= new Car("Swift","UP12AD7234","5645565","43243667",10,2, 8,5000,10000,new Owner("Satish",645565465));
		Car car4= new Car("Swift","UP12AD1243","4533453","34234234",10,2, 8,5000,10000,new Owner("Girish",223423434));
		CarServiceDbUtil.carInfo.put(car1.getRegistrationNumber(),car1);
		CarServiceDbUtil.carInfo.put(car2.getRegistrationNumber(),car2);
		CarServiceDbUtil.carInfo.put(car3.getRegistrationNumber(),car3);
		CarServiceDbUtil.carInfo.put(car4.getRegistrationNumber(),car4);
		
	}
	
	@Test
	public void registerCustomerForValidCustomer() throws RegistrationNumberNotFound {
		Car carActual= new Car("Swift","UP12AD7844","1234556","34234234",10,2, 8,5000,10000,new Owner("Prajjval",828485087));
		//Car carExpected = service.registerCustomer("Swift","UP12AD7844","1234556","34234234",10,2, 8,5000,10000,new Owner("Prajjval",828485087));
		//assertEquals(carActual,carExpected);
	}
	
	@Test(expected = RegistrationNumberNotFound.class)
	public void registerCustomerForInvalidCustomer() throws RegistrationNumberNotFound{
		service.findOne("UP12AD7814");
	}
	
	@Test
	public void carServiceForValidCustomer() throws RegistrationNumberNotFound {
		Car carDetails = service.carService("UP12AD7844");
		Car carDetails1 = service.carService("UP12AD7844");
		assertEquals(carDetails1, carDetails);
	}
	
	@Test(expected = RegistrationNumberNotFound.class)
	public void carServiceForInvalidCustomer() throws RegistrationNumberNotFound{
		Car carDetails = service.carService("UP12AD7844");
		Car carDetails1 = service.carService("UP12A44");
		assertEquals(carDetails, carDetails1);
	} 
	
	@Test
	public void findOneForValidCustomer() throws RegistrationNumberNotFound {
		Car carDetails = service.findOne("UP12AD7844");
		Car carDetails1 = service.findOne("UP12AD7844");
		assertEquals(carDetails, carDetails1);
	}
	
	@Test(expected = RegistrationNumberNotFound.class)
	public void findOneForInvalidCustomer() throws RegistrationNumberNotFound {
		Car carDetails = service.findOne("UP12AD7844");
		Car carDetails1 = service.findOne("UP12AD74");
		assertEquals(carDetails, carDetails1);
	}
	
	@AfterClass
	public static void tearDownTestEnv() {
		service=null;
		CarServiceDbUtil.carInfo.clear();
	}
	
}
