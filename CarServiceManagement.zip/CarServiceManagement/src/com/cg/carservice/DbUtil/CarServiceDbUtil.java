package com.cg.carservice.DbUtil;
import com.cg.carservice.bean.*;
import java.util.HashMap;

public class CarServiceDbUtil {
public static HashMap<String,Car>carInfo = new HashMap<>();

}
